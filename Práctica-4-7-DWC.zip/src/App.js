import React from 'react';
import logo from './logo.svg';
import './App.css';
import GeneraNums from './GeneraNums';
import Euromillon from './Euromillon';

function App() {
  return (
    <React.Fragment>
      {/*Ejercicio1*/}
      <GeneraNums></GeneraNums>
      {/*Ejercicio2*/}
      {/* <Euromillon></Euromillon> */}
    </React.Fragment>
    
  );
}

export default App;
